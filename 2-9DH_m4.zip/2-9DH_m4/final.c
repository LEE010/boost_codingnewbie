#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int val;
    struct node *left;
    struct node *right;
} Node;

Node *init_node(int val);
void insert_node(Node **node, int val);
void print(Node *root);
void inorder(Node *node);

int main(void)
{
    int N, temp;
    Node *root = NULL;

    scanf("%d", &N);

    for (size_t i = 0; i < N; i++)
    {
        scanf("%d", &temp);
        insert_node(&root, temp);
    }

    print(root);
}

Node *init_node(int val)
{
    Node *node = (Node *)malloc(sizeof(Node));
    node->val = val;
    node->left = NULL;
    node->right = NULL;

    return node;
}

void insert_node(Node **node, int val)
{
    if (*node == NULL)
    {
        *node = init_node(val);
        return;
    }
    if ((*node)->val == val)
        return;
    else if ((*node)->val > val)
        insert_node(&((*node)->left), val);
    else
        insert_node(&((*node)->right), val);
}

void print(Node *root)
{
    printf("[");
    inorder(root);
    printf(" ]\n");
}

void inorder(Node *node)
{
    if (node == NULL)
        return;
    inorder(node->left);
    printf(" %d", node->val);
    inorder(node->right);
}